//REPOBEE-SANITIZER-SHRED
/*  
 *  This file contains reference solutions for ListPorcessorTest,
 *  The SHRED marker above ensures this file does not make it to
 *  the master branch, which students have access to 
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Arrays;

/**
 * ListProcessor is a class creating and manipulating
 * lists and arrays of integers.
 */
public class ListProcessor {

    private final Random random = new Random();

    /**
     * Create an array containing a range of integers.
     * When given a negative range an empty array will be returned.
     *
     * @param from the lower bound of the range (inclusive)
     * @param to the upper bound of the range (exclusive)
     * @return the array
     */
    public int[] arraySequence(int from, int to) {
        if (from > to) {
            throw new IllegalArgumentException(
                "The lower bound must be smaller than"
                + " or equal to the upper bound");
        }
        int[] numbers = new int[to - from];
        for (int i = from; i < to; i++) {
            numbers[i - from] = i;
        }
        return numbers;
    }

    /**
     * Create a list containing a range of integers.
     * When given a negative range an empty list will be returned.
     *
     * @param from the lower bound of the range (inclusive)
     * @param to the upper bound of the range (exclusive)
     * @return the list
     */
    public List<Integer> listSequence(int from, int to) {
        if (from > to) {
            throw new IllegalArgumentException(
                "The lower bound must be smaller than"
                + " or equal to the upper bound");
        }
        List<Integer> numbers = new ArrayList<Integer>();
        for (int i = from; i < to; i++) {
            numbers.add(i);
        }
        return numbers;
    }

    /**
     * Shuffle an array of integers with a Fisher-Yates shuffle.
     *
     * @param numbers the array of integers
     * @return the array with shuffled elements
     */
    public int[] shuffled(int[] numbers) {
        int[] copy = numbers.clone();
        for (int i = 0; i < numbers.length; i++) {
            int j = random.nextInt(copy.length - i) + i;
            int temp = copy[i];
            copy[i] = copy[j];
            copy[j] = temp;
        }
        return copy;
    }

    /**
     * Shuffle a list of integers with a Fisher-Yates shuffle.
     *
     * @param numbers the list of integers
     * @return the list with shuffled elements
     */
    public List<Integer> shuffled(List<Integer> numbers) {
        List<Integer> copy = new ArrayList<>(numbers);
        for (int i = 0; i < copy.size(); i++) {
            int j = random.nextInt(copy.size() - i) + i;
            copy.set(i, copy.set(j, copy.get(i)));
        }
        return copy;
    }

    /**
     * Sum all elements in an array of integers iteratively.
     *
     * @param numbers the array of integers
     * @return the sum
     */
    public int sumIterative(int[] numbers) {
        int sum = 0;
        for (int number : numbers) {
            sum += number;
        }
        return sum;
    }

    /**
     * Sum all elements in a list of integers iteratively.
     *
     * @param numbers the list of integers
     * @return the sum
     */
    public int sumIterative(List<Integer> numbers) {
        int sum = 0;
        for (int number : numbers) {
            sum += number;
        }
        return sum;
    }

    /**
     * Sum all elements in an array of integers recursively.
     * If there's no elements in the array, the result will be 0.
     *
     * @param numbers the array of integers
     * @return the sum
     */
    public int sumRecursive(int[] numbers) {
        if (numbers.length == 0) {
            return 0;
        }
        if (numbers.length == 1) {
            return numbers[0];
        }
        return numbers[numbers.length - 1]
            + sumRecursive(Arrays.copyOf(numbers, numbers.length - 1));
    }

    /**
     * Sum all elements in a list of integers recursively.
     * If there's no elements in the list, the result will be 0.
     *
     * @param numbers the list of integers
     * @return the sum
     */
     public int sumRecursive(List<Integer> numbers) {
        if (numbers.isEmpty()) {
            return 0;
        }
        if (numbers.size() == 1) {
            return numbers.get(0);
        }
        return numbers.get(0)
            + sumRecursive(numbers.subList(1, numbers.size()));
    }

}
