//REPOBEE-SANITIZER-SHRED
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class RectangleTest {

    public static final int RECT_WIDTH = 40;
    public static final int RECT_HEIGHT = 50;
    public static final int SQUARE_SIDE = 20;

    public static final double DIAGNONAL_ERROR_MARGIN = 0.1;

    private static Rectangle rectangle;
    private static Rectangle square;

    @BeforeClass
    public static void setUp() {
        rectangle = new Rectangle();
        rectangle.setWidth(RECT_WIDTH);
        rectangle.setHeight(RECT_HEIGHT);

        square = new Rectangle();
        square.setWidth(SQUARE_SIDE);
        square.setHeight(SQUARE_SIDE);
    }

    @Test
    public void testRectangleArea() {
        assertEquals(RECT_WIDTH * RECT_HEIGHT, rectangle.area());
    }

    @Test
    public void testSquareArea() {
        assertEquals(SQUARE_SIDE * SQUARE_SIDE, square.area());
    }

    @Test
    public void testRectangleDiagonalLength() {
        double expectedDiagonal = Math.sqrt(RECT_WIDTH * RECT_WIDTH + RECT_HEIGHT * RECT_HEIGHT);
        assertEquals(expectedDiagonal, rectangle.diagonalLength(), DIAGNONAL_ERROR_MARGIN);
    }

    @Test
    public void testSquareDiagonalLength() {
        double expectedDiagonal = Math.sqrt(SQUARE_SIDE * SQUARE_SIDE * 2);
        assertEquals(expectedDiagonal, square.diagonalLength(), DIAGNONAL_ERROR_MARGIN);
    }

    @Test
    public void testRectangleIsSquare() {
        assertFalse(rectangle.isSquare());
    }

    @Test
    public void testSquareIsSquare() {
        assertTrue(square.isSquare());
    }
}
