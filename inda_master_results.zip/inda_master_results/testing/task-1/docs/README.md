#### Exercise 0.1
What are the two things you need to do to pass an assignment?

> **Student's Answer:** 
REPOBEE-SANITIZER-START
> Submit my solutions on time and attend the exercise.
REPOBEE-SANITIZER-REPLACE-WITH
> Submit your answer here
REPOBEE-SANITIZER-END

#### Exercise 0.2
When, at the latest, must your assignment be pushed to KTH GitHub? It may be
helpful to use a hypothetical example.

> **Student's Answer:** 
REPOBEE-SANITIZER-START
> Before the beginning of the week's exercise. If my exercise begins at 10:15, my solution must be pushed by 10:14 at the latest.
REPOBEE-SANITIZER-REPLACE-WITH
> Submit your answer here
REPOBEE-SANITIZER-END
#### Exercise 0.3
What should you do if you know that you are unable to attend an exercise, or
submit the assignments in time?

> **Student's Answer:** 
REPOBEE-SANITIZER-START
> I should contact my TA as soon as possible and explain my problem.
REPOBEE-SANITIZER-REPLACE-WITH
> Submit your answer here
REPOBEE-SANITIZER-END

#### Exercise 0.4
When names/headers of classes and methods are given, should you use them
exactly as they are given? Why or why not? Do uppercase and lowercase
letters matter?

> **Student's Answer:** 
REPOBEE-SANITIZER-START
> I should use them exactly as given, since Java is a case sensitive language. "Foo" and "foo" and "fOO" are not the same in Java.
REPOBEE-SANITIZER-REPLACE-WITH
> Submit your answer here
REPOBEE-SANITIZER-END

#### Exercise 0.5
Is it okay to copy solutions from another student, if you do it just once in a
while?

> **Student's Answer:** 
REPOBEE-SANITIZER-START
> No.
REPOBEE-SANITIZER-REPLACE-WITH
> Submit your answer here
REPOBEE-SANITIZER-END

#### Exercise 0.6
Give two examples of when it is **not** okay to copy code from the internet.

> **Student's Answer:** 
REPOBEE-SANITIZER-START
> When I copy more than a trivial snippet, or when I don't understand the code I copy.
REPOBEE-SANITIZER-REPLACE-WITH
> Submit your answer here
REPOBEE-SANITIZER-END

#### Exercise 0.7
What are the types of the following values?

> **Assistant's Note:** your answer should be `int`, `double`, `String`, `boolean` et c.

> **Student's Answer:** 

<!--REPOBEE-SANITIZER-START-->

| Value     | Answer                 |
|-----------|------------------------|
| `0`       | int                    |
| `"hello"` | String                 |
| `101`     | int                    |
| `-1`      | int                    |
| `true`    | boolean                |
| `"33"`    | String                 |
| `3.1415`  | double (or float)      |

<!--REPOBEE-SANITIZER-REPLACE-WITH-->
<!--| Value     | Answer                 |
<!--|-----------|------------------------|
<!--| `0`       | WRITE YOUR ANSWER HERE |
<!--| `"hello"` | ...                    |
<!--| `101`     |                        |
<!--| `-1`      |                        |
<!--| `true`    |                        |
<!--| `"33"`    |                        |
<!--| `3.1415`  |                        |
<!--REPOBEE-SANITIZER-END-->