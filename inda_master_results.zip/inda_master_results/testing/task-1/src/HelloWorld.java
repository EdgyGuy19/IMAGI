// REPOBEE-SANITIZER-SHRED 

/**
 * Hello, world!
 * Prints the welcoming, dreamy, and hopeful message "Hello, world!" to the
 * terminal when executed.
 */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, world!");    
    }    
}
