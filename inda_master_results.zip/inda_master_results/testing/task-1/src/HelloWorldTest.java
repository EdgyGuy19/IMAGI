// REPOBEE-SANITIZER-SHRED
import org.junit.Ignore;
import org.junit.Test;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.regex.Pattern;

public class HelloWorldTest {
    @Test
    @Ignore // FIXME: Tests that redirect stdout seem to fail when using repobee, this test has been disabled for now
    public void testHelloWorldWritesHelloWorld() {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));

        HelloWorld.main(null);

        ByteArrayInputStream written = new ByteArrayInputStream(out.toByteArray());

        int numBytes = written.available();
        byte[] bytes = new byte[numBytes];
        written.read(bytes, 0, numBytes);
        String printedString = new String(bytes).toLowerCase();

        Pattern pattern = Pattern.compile("hello.*world.*(\n)?");
        boolean hasPrintedHelloWorld = pattern.matcher(printedString).matches();

        assertTrue(hasPrintedHelloWorld);
    }
}