#### Exercise 1.1
| Boolean expression | Value   |
|--------------------|---------|
| `2 == 5`           | `false` |
| `2 > 5`            |         |
| `11 == 11`         |         |
| `7 <= 9`           |         |
| `42 >= 7`          |         |
| `false == true`    |         |

#### Exercise 1.2
| Boolean expression     | Value |
|------------------------|-------|
| `2 == 3 && 2 == 2`     |       |
| `2 == 3 \|\| 2 == 2`   |       |
| `!true`                |       |
| `!false`               |       |

#### Exercise 1.3
| Boolean expression             | Value  |
|--------------------------------|--------|
| `true \|\| (true && false)`    | `true` |
| `false \|\| (false \|\| true)` |        |
| `!(false && true) == true`     |        |
| `!true && false`               |        |
| `!(true && false)`             |        |
