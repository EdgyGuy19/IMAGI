REPOBEE-SANITIZER-SHRED

#### Exercise 1.1
| Boolean expression | Value   |
|--------------------|---------|
| `2 == 5`           | `false` |
| `2 > 5`            | `false` |
| `11 == 11`         | `true`  |
| `7 <= 9`           | `true`  |
| `42 >= 7`          | `true`  |
| `false == true`    | `false` |

#### Exercise 1.2
| Boolean expression     | Value  |
|------------------------|--------|
| `2 == 3 && 2 == 2`     | `false`|
| `2 == 3 \|\| 2 == 2`   | `true` |
| `!true`                | `false`|
| `!false`               | `true` |

#### Exercise 1.3
| Boolean expression             | Value  |
|--------------------------------|--------|
| `true \|\| (true && false)`    | `true` |
| `false \|\| (false \|\| true)` | `true` |
| `!(false && true) == true`     | `true` |
| `!true && false`               | `false` |
| `!(true && false)`             | `true`  |
