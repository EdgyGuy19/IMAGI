//REPOBEE-SANITIZER-SHRED
public class InsertionSortTest extends IntSorterTest {
    @Override
    protected IntSorter getSorter() {
        return new InsertionSort();
    }
}
