//REPOBEE-SANITIZER-START
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.rules.Timeout;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Collection;

import static org.junit.Assert.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.CoreMatchers.*;

import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public abstract class IntSorterTest {
    @Rule public Timeout globalTimeout = Timeout.seconds(5);

    // parameterization, each element in the returned collection results in one test.
    @Parameters(name = "{0}")
    public static Collection<TestCase> testCases() {
        int n = 10_000;
        TestCase allEqual = new TestCase("all elements equal", new Data(n, 1, Data.Order.RANDOM));
        TestCase randomlyOrdered = new TestCase("random order", new Data(n, n, Data.Order.RANDOM));
        TestCase ascending = new TestCase("ascending order", new Data(n, n, Data.Order.ASCENDING));
        TestCase descending =
            new TestCase("descending order", new Data(n, n, Data.Order.DESCENDING));
        TestCase empty = new TestCase("empty array", new Data(0, n, Data.Order.RANDOM));
        // odd and even length mostly to catch off-by-one errors in the `sort` method
        int evenN = (n / 2) * 2;
        TestCase oddLength =
            new TestCase("odd length, random order", new Data(evenN + 1, n, Data.Order.RANDOM));
        TestCase evenLength =
            new TestCase("even length, random order", new Data(evenN, n, Data.Order.RANDOM));

        return List.of(
            empty, allEqual, randomlyOrdered, ascending, descending, oddLength, evenLength);
    }

    private IntSorter sorter;
    // Must be public, or dependency injection fails!
    @Parameter public TestCase tc;

    @Before
    public void setUp() {
        sorter = getSorter();
    }

    protected abstract IntSorter getSorter();

    @Test
    public void test() {
        int[] expected = tc.data.get();
        int[] actual = tc.data.get();
        Arrays.sort(expected);

        sorter.sort(actual);

        assertThat(actual, equalTo(expected));
    }

    private static class TestCase {
        final String name;
        final Data data;

        TestCase(String name, Data data) {
            this.name = name;
            this.data = data;
        }

        @Override
        public String toString() {
            return name;
        }
    }
}
//REPOBEE-SANITIZER-REPLACE-WITH
// import org.junit.Test;
// import org.junit.Before;
// import static org.junit.Assert.*;
//
// import static org.hamcrest.MatcherAssert.assertThat;
// import static org.hamcrest.CoreMatchers.*;
//
// /**
//  * Abstract test class for  implementations.
//  *
//  * Implementing test classes must override the getIntSorter method.
//  *
//  * @author Simon Larsén
//  * @version 2018-01-16
//  */
// public abstract class IntSorterTest {
//     /**
//      * Returns an implementation of the IntSorter interface. Extending classes
//      * must override this method.
//      *
//      * @return An implementation of IntSorter.
//      */
//     protected abstract IntSorter getIntSorter();
//
//     @Before
//     public void setUp() {
//     }
// }
//REPOBEE-SANITIZER-END
