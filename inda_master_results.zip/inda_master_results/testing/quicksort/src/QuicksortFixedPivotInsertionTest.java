//REPOBEE-SANITIZER-SHRED
public class QuicksortFixedPivotInsertionTest extends IntSorterTest {
    @Override
    protected IntSorter getSorter() {
        return new QuicksortFixedPivotInsertion();
    }
}
