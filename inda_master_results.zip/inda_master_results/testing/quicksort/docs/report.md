# A Study of Quicksort

## Characteristics and Complexity

	In this section, briefly discuss:
	* Origins of Quicksort
	* Its characteristics
	* Its runtime complexity

## Variations of Quicksort

	In this section:
	* Outline each variation you implemented
	* Include snippets of code where relevant (e.g. different partition routines)
	* Discuss your cut-off strategy

## Methodology

	In this section, describe the tests you performed, making reference to:
	* Test data
	* Problem size
	* Algorithms used

## Results

	In this section:
	* Present a table for the data from each test
	* Generate charts (use Matlab or another tool) to show the data
	* Ensure you label each clearly

## Discussion

	In this section:
	* Discuss your general findings based on the data
	* What was surprising
	* What met your expectations
	* Which variation was closet to Arrays.sort?