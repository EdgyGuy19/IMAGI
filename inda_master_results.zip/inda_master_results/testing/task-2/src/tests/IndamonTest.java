//REPOBEE-SANITIZER-SHRED
import org.junit.Test;
import org.junit.Before;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


public class IndamonTest {

    private Indamon arvidKarlSixtenSiberov;
    private Indamon mollyMajOstkrok;
    private String[] fieldNames;

    // Molly's stats
    private static final int MOLLY_HP = 100;
    private static final int MOLLY_ATTACK = 20;
    private static final int MOLLY_DEFENSE = 11;

    // Arvid's stats
    private static final int ARVID_HP = 50;
    private static final int ARVID_ATTACK = 10;
    private static final int ARVID_DEFENSE = 2;

    @Before
    public void setUp(){
        mollyMajOstkrok = new Indamon("Molly Maj Ostkrok", MOLLY_HP, MOLLY_ATTACK, MOLLY_DEFENSE);
        arvidKarlSixtenSiberov = new Indamon("Arvid Karl Sixten Siberov", ARVID_HP, ARVID_ATTACK, ARVID_DEFENSE);
        fieldNames = new String[]{"name", "attack", "defense", "hp"};
    }

    // Correct access modifiers
    @Test
    public void checkThatAccessModifiersOfFieldsArePrivateAndMethodsHaveRightNames() throws NoSuchFieldException {
        for (String fieldName : this.fieldNames) {
            assertTrue(Modifier.isPrivate(Indamon.class.getDeclaredField(fieldName).getModifiers()));
        }
    }

    // Attack works as intended
    @Test
    public void attackIsCorrectlyCalculated(){
        mollyMajOstkrok.attack(arvidKarlSixtenSiberov);
        assertEquals(arvidKarlSixtenSiberov.getHp(), ARVID_HP - MOLLY_ATTACK / ARVID_DEFENSE);
    }
}



