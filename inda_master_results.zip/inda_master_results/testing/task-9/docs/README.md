### Optimizations for the Sieve of Eratosthenes

REPOBEE-SANITIZER-START  
A few potential improvements that the students could suggest are:
* Only store odd numbers in the `primeCache`, since the only even prime is 2 and this could be handled as a special case.
* Start the inner loop at `j = i*i`, since all smaller multiples of `i` has already been checked.
* For primes greater than 2, increment the inner loop as `j += i*2` since even multiples of `i` are already marked as 
  non-prime.
* Check if the number is divisible by the first few primes. Since 50 % of all numbers are divisible by 2
  about 33 % by 3, 20 % by 5 etc. this can serve as a quick primality test. 
* Use the fact that every prime greater than 3 is congruent to 1 or 5 (mod 6) ([source](https://primes.utm.edu/notes/faq/six.html)).
  This could be implemented as a quick check before the sieve algorithm is run.
* Use some other [primality test](https://en.wikipedia.org/wiki/Primality_test) before running the sieve algorithm.

A solution that _won't_ work is to extend the prime cache instead of recalculating it when a new, larger number
is provided as an argument to `isPrime`. 

REPOBEE-SANITIZER-REPLACE-WITH  
Describe your ideas for one or more optimizations of the sieve algorithm here. Try to give a reasonably detailed 
description of how they could be implemented and why it would improve the performance of the program.  
REPOBEE-SANITIZER-END